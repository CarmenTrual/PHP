<hr/>
<nav>
    Menú de navegación: 
    <a href='index.php?action=mostrarListaTareas'>Mis tareas</a>
    <a href='cerrarSesion.php'>Cerrar sesión</a>
</nav>
<hr/>