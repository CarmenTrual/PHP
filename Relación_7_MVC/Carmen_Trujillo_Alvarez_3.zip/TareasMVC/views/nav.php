<hr/>
<nav>
    Menú de navegación: 
    <a href='index.php'>Home</a>
    <a href='index.php?action=mostrarListaTareas'>Tarea</a>
    <a href='cerrarSesion.php'>Cerrar sesión</a>
</nav>
<hr/>